﻿using BooksWebApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace BooksWebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BooksController : ControllerBase
    {
        private static List<Book> books = new()
        {
            new Book { Id = 1, Title = "Clean Code", Author = "Robert Martin", Year = 2008 },
            new Book { Id = 2, Title = "1984", Author = "George Orwell", Year = 1949 }
        };

        [HttpGet]
        public ActionResult<List<Book>> GetBooks()
        {
            return Ok(books);
        }

        [HttpPost]
        public ActionResult<Book> AddBook(Book newBook)
        {
            newBook.Id = books.Any() ? books.Max(b => b.Id) + 1 : 1;
            books.Add(newBook);
            return Ok(newBook);
        }
    }
}